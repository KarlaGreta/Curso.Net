namespace   Aseguradora.Aplicacion;

public class EliminarVehiculoUseCase 
{
    private readonly IRepositorioTitular _repo;

    public EliminarVehiculoUseCase(IRepositorioTitular repo)
    {
        _repo = repo;
    }

    // ejecutar falta
}
