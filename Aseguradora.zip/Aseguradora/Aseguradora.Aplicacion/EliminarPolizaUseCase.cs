namespace   Aseguradora.Aplicacion;

public class EliminarPolizaUseCase 
{
    private readonly IRepositorioTitular _repo;

    public EliminarPolizaUseCase(IRepositorioTitular repo)
    {
        _repo = repo;
    }

    // ejecutar falta
}




