namespace   Aseguradora.Aplicacion;

public class ModificarPolizaUseCase 
{
    private readonly IRepositorioTitular _repo;

    public ModificarPolizaUseCase(IRepositorioTitular repo)
    {
        _repo = repo;
    }

    // ejecutar falta
}
