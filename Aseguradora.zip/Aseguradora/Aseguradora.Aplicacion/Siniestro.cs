namespace   Aseguradora.Aplicacion;

public  class Siniestro{

    private int _Id{get;set;}
    private int PolizaId{get;set;}
    private DateOnly _ingreso{get;}
    private DateOnly _ocurrencia{get;set;}
    private string? _direccion{get;set;}
    private string? _descripcion{get;set;}
    
}