namespace   Aseguradora.Aplicacion;

public class ModificarVehiculoUseCase 
{
    private readonly IRepositorioTitular _repo;

    public ModificarVehiculoUseCase(IRepositorioTitular repo)
    {
        _repo = repo;
    }

    // ejecutar falta
}
